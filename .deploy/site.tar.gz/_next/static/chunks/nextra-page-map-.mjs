import meta from "../../../pages/_meta.js";
import docs_meta from "../../../pages/docs/_meta.js";
import en_meta from "../../../pages/en/_meta.js";
import en_docs_meta from "../../../pages/en/docs/_meta.js";
export const pageMap = [{
  data: meta
}, {
  name: "docs",
  route: "/docs",
  children: [{
    data: docs_meta
  }, {
    name: "00-product-overview",
    route: "/docs/00-product-overview",
    frontMatter: {
      "sidebarTitle": "00 Product Overview"
    }
  }, {
    name: "01-quickstart",
    route: "/docs/01-quickstart",
    frontMatter: {
      "sidebarTitle": "01 Quickstart"
    }
  }, {
    name: "02-core-concepts",
    route: "/docs/02-core-concepts",
    frontMatter: {
      "sidebarTitle": "02 Core Concepts"
    }
  }, {
    name: "03-architecture",
    route: "/docs/03-architecture",
    frontMatter: {
      "sidebarTitle": "03 Architecture"
    }
  }, {
    name: "04-surface-stack",
    route: "/docs/04-surface-stack",
    frontMatter: {
      "sidebarTitle": "04 Surface Stack"
    }
  }, {
    name: "05-packages",
    route: "/docs/05-packages",
    frontMatter: {
      "sidebarTitle": "05 Packages"
    }
  }, {
    name: "06-configuration",
    route: "/docs/06-configuration",
    frontMatter: {
      "sidebarTitle": "06 Configuration"
    }
  }, {
    name: "07-providers-and-models",
    route: "/docs/07-providers-and-models",
    frontMatter: {
      "sidebarTitle": "07 Providers and Models"
    }
  }, {
    name: "08-agent-development",
    route: "/docs/08-agent-development",
    frontMatter: {
      "sidebarTitle": "08 Agent Development"
    }
  }, {
    name: "09-attachment-system",
    route: "/docs/09-attachment-system",
    frontMatter: {
      "sidebarTitle": "09 Attachment System"
    }
  }, {
    name: "10-extensions-and-skills",
    route: "/docs/10-extensions-and-skills",
    frontMatter: {
      "sidebarTitle": "10 Extensions and Skills"
    }
  }, {
    name: "11-aigc-and-vision-tools",
    route: "/docs/11-aigc-and-vision-tools",
    frontMatter: {
      "sidebarTitle": "11 Aigc and Vision Tools"
    }
  }, {
    name: "12-web-ui-extension",
    route: "/docs/12-web-ui-extension",
    frontMatter: {
      "sidebarTitle": "12 Web UI Extension"
    }
  }, {
    name: "13-config-ui",
    route: "/docs/13-config-ui",
    frontMatter: {
      "sidebarTitle": "13 Config UI"
    }
  }, {
    name: "14-sessions-list",
    route: "/docs/14-sessions-list",
    frontMatter: {
      "sidebarTitle": "14 Sessions List"
    }
  }, {
    name: "15-message-queue",
    route: "/docs/15-message-queue",
    frontMatter: {
      "sidebarTitle": "15 Message Queue"
    }
  }, {
    name: "16-canvas-workbench",
    route: "/docs/16-canvas-workbench",
    frontMatter: {
      "sidebarTitle": "16 Canvas Workbench"
    }
  }, {
    name: "17-canvas-plugins",
    route: "/docs/17-canvas-plugins",
    frontMatter: {
      "sidebarTitle": "17 Canvas Plugins"
    }
  }, {
    name: "18-cli",
    route: "/docs/18-cli",
    frontMatter: {
      "sidebarTitle": "18 CLI"
    }
  }, {
    name: "19-deployment",
    route: "/docs/19-deployment",
    frontMatter: {
      "sidebarTitle": "19 Deployment"
    }
  }, {
    name: "20-desktop-tauri",
    route: "/docs/20-desktop-tauri",
    frontMatter: {
      "sidebarTitle": "20 Desktop Tauri"
    }
  }, {
    name: "21-logging",
    route: "/docs/21-logging",
    frontMatter: {
      "sidebarTitle": "21 Logging"
    }
  }, {
    name: "22-development-and-testing",
    route: "/docs/22-development-and-testing",
    frontMatter: {
      "sidebarTitle": "22 Development and Testing"
    }
  }, {
    name: "23-troubleshooting-faq",
    route: "/docs/23-troubleshooting-faq",
    frontMatter: {
      "sidebarTitle": "23 Troubleshooting Faq"
    }
  }, {
    name: "24-http-api-reference",
    route: "/docs/24-http-api-reference",
    frontMatter: {
      "sidebarTitle": "24 HTTP API Reference"
    }
  }, {
    name: "25-roadmap",
    route: "/docs/25-roadmap",
    frontMatter: {
      "sidebarTitle": "25 Roadmap"
    }
  }, {
    name: "26-glossary",
    route: "/docs/26-glossary",
    frontMatter: {
      "sidebarTitle": "26 Glossary"
    }
  }, {
    name: "index",
    route: "/docs",
    frontMatter: {
      "sidebarTitle": "Index"
    }
  }]
}, {
  name: "en",
  route: "/en",
  children: [{
    data: en_meta
  }, {
    name: "docs",
    route: "/en/docs",
    children: [{
      data: en_docs_meta
    }, {
      name: "00-product-overview",
      route: "/en/docs/00-product-overview",
      frontMatter: {
        "sidebarTitle": "00 Product Overview"
      }
    }, {
      name: "01-quickstart",
      route: "/en/docs/01-quickstart",
      frontMatter: {
        "sidebarTitle": "01 Quickstart"
      }
    }, {
      name: "02-core-concepts",
      route: "/en/docs/02-core-concepts",
      frontMatter: {
        "sidebarTitle": "02 Core Concepts"
      }
    }, {
      name: "03-architecture",
      route: "/en/docs/03-architecture",
      frontMatter: {
        "sidebarTitle": "03 Architecture"
      }
    }, {
      name: "04-surface-stack",
      route: "/en/docs/04-surface-stack",
      frontMatter: {
        "sidebarTitle": "04 Surface Stack"
      }
    }, {
      name: "05-packages",
      route: "/en/docs/05-packages",
      frontMatter: {
        "sidebarTitle": "05 Packages"
      }
    }, {
      name: "06-configuration",
      route: "/en/docs/06-configuration",
      frontMatter: {
        "sidebarTitle": "06 Configuration"
      }
    }, {
      name: "07-providers-and-models",
      route: "/en/docs/07-providers-and-models",
      frontMatter: {
        "sidebarTitle": "07 Providers and Models"
      }
    }, {
      name: "08-agent-development",
      route: "/en/docs/08-agent-development",
      frontMatter: {
        "sidebarTitle": "08 Agent Development"
      }
    }, {
      name: "09-attachment-system",
      route: "/en/docs/09-attachment-system",
      frontMatter: {
        "sidebarTitle": "09 Attachment System"
      }
    }, {
      name: "10-extensions-and-skills",
      route: "/en/docs/10-extensions-and-skills",
      frontMatter: {
        "sidebarTitle": "10 Extensions and Skills"
      }
    }, {
      name: "11-aigc-and-vision-tools",
      route: "/en/docs/11-aigc-and-vision-tools",
      frontMatter: {
        "sidebarTitle": "11 Aigc and Vision Tools"
      }
    }, {
      name: "12-web-ui-extension",
      route: "/en/docs/12-web-ui-extension",
      frontMatter: {
        "sidebarTitle": "12 Web UI Extension"
      }
    }, {
      name: "13-config-ui",
      route: "/en/docs/13-config-ui",
      frontMatter: {
        "sidebarTitle": "13 Config UI"
      }
    }, {
      name: "14-sessions-list",
      route: "/en/docs/14-sessions-list",
      frontMatter: {
        "sidebarTitle": "14 Sessions List"
      }
    }, {
      name: "15-message-queue",
      route: "/en/docs/15-message-queue",
      frontMatter: {
        "sidebarTitle": "15 Message Queue"
      }
    }, {
      name: "16-canvas-workbench",
      route: "/en/docs/16-canvas-workbench",
      frontMatter: {
        "sidebarTitle": "16 Canvas Workbench"
      }
    }, {
      name: "17-canvas-plugins",
      route: "/en/docs/17-canvas-plugins",
      frontMatter: {
        "sidebarTitle": "17 Canvas Plugins"
      }
    }, {
      name: "18-cli",
      route: "/en/docs/18-cli",
      frontMatter: {
        "sidebarTitle": "18 CLI"
      }
    }, {
      name: "19-deployment",
      route: "/en/docs/19-deployment",
      frontMatter: {
        "sidebarTitle": "19 Deployment"
      }
    }, {
      name: "20-desktop-tauri",
      route: "/en/docs/20-desktop-tauri",
      frontMatter: {
        "sidebarTitle": "20 Desktop Tauri"
      }
    }, {
      name: "21-logging",
      route: "/en/docs/21-logging",
      frontMatter: {
        "sidebarTitle": "21 Logging"
      }
    }, {
      name: "22-development-and-testing",
      route: "/en/docs/22-development-and-testing",
      frontMatter: {
        "sidebarTitle": "22 Development and Testing"
      }
    }, {
      name: "23-troubleshooting-faq",
      route: "/en/docs/23-troubleshooting-faq",
      frontMatter: {
        "sidebarTitle": "23 Troubleshooting Faq"
      }
    }, {
      name: "24-http-api-reference",
      route: "/en/docs/24-http-api-reference",
      frontMatter: {
        "sidebarTitle": "24 HTTP API Reference"
      }
    }, {
      name: "25-roadmap",
      route: "/en/docs/25-roadmap",
      frontMatter: {
        "sidebarTitle": "25 Roadmap"
      }
    }, {
      name: "26-glossary",
      route: "/en/docs/26-glossary",
      frontMatter: {
        "sidebarTitle": "26 Glossary"
      }
    }, {
      name: "index",
      route: "/en/docs",
      frontMatter: {
        "sidebarTitle": "Index"
      }
    }]
  }]
}, {
  name: "index",
  route: "/",
  frontMatter: {
    "title": "pi-web",
    "sidebar": false
  }
}];